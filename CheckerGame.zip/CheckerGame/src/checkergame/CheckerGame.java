/*Program created by Arup, Andy, Mohamed
 *objects and methods were used, however had to be done in one class due to the use of paint
 *2 Player Checker Game w/ our own variation
 *Rules: Moving pieces work just like checkers however, there are no kings in the game. Instead, the first player to get their
 piece to the end of the board wins. There is also no double jumping to make the matchs more difficult. 
 */
package checkergame;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;


/**
 *
 * @author S332652833
 */
public class CheckerGame extends Frame implements MouseListener {

    //List of variables
    //Arrays for x and y positions of the red and blue pieces
    public int xred[] = new int[12];
    public int yred[] = new int[12];
    public int xblue[] = new int[12];
    public int yblue[] = new int[12];
    //Var for determining which player turn it is, turn = 1 for blue, turn = 2 for red
    public int turn = 1;
    //Var for determining which player wins
    public int win = 0;
    //var for determining how the piece will move
    public int move = 0;
    //variables for determing what open positions there are for the piece to move
    public int pos1, pos2, pos3, pos4, pos5, pos6 = 0;
    //var for remembering x and y position of selected piece
    public int xval, yval;
    //var count for remembering which piece is being changed
    public int count;
    //var for remembering which enemy piece will be affected
    public int enemy1, enemy2;
    //var for player pieces left remaining, if it hits zero player loses
    public int redlive, bluelive;
    //for determining if a piece is being selected or being moved
    public int selection = 0;

    //Creates a label that will tell whos turn it is
    Label l;
    Color c = Color.BLUE;

    //sets up mouse and screen to print to
    CheckerGame() {
        l = new Label();
        l.setBounds(10, 40, 70, 20);
        add(l);

        addMouseListener(this);

        setLayout(null);
        setTitle("2 Player Checkers");
        setSize(600, 600);
        setVisible(true);
        setResizable(false);

    }

//---------------------------------------------------------------------------------------------------------------------------------------------       
    
    //paints the board and places the pieces in their original starting locations
    public void paint(Graphics g) {
        setBackground(Color.LIGHT_GRAY);
        board();
        ResetPiece();
        print();
    }

//---------------------------------------------------------------------------------------------------------------------------------------------       
    
    public void mouseClicked(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mousePressed(MouseEvent e) {}
    
    //everytime mouse is clicked, game will reprint to update pos and determine if mouse has clicked on a valid position
    public void mouseReleased(MouseEvent e) {
        board();
        print();     
        //looks for a piece when the mouse is clicked 
        if (selection == 0) {
            //if mouse clicked on a piece, game finds piece location
            findpiece(e.getX(), e.getY());
        }
        //if the piece is already selected, will then check for a valid square to move on click
        //will make sure of whos turn it is, update board, update turn, and search for a game over
        //turn = 1 for blue turn
        else if (selection == 1 && turn == 1) {
            moveblue(e.getX(), e.getY(), xval, yval);
            board();
            print();
            gameover();
            l.setText("RED Turn");
            
        //turn = 2 for red turn
        } else if (selection == 1 && turn == 2) {
            movered(e.getX(), e.getY(), xval, yval);
            board();
            print();
            gameover();
            l.setText("BLUE Turn");
        
        //when game is over, finds if player clicks on restart or quit
        } else if(selection == 2){
            if ((e.getX() >= 100 && e.getX() <= 200 && e.getY() >= 520 && e.getY() <= 570)){
                repaint();
            } else if ((e.getX() >= 400 && e.getX() <= 500 && e.getY() >= 520 && e.getY() <= 570)){
                System.exit(0);
            }
        }
    }

 //---------------------------------------------------------------------------------------------------------------------------------------------      
    
    public static void main(String[] args) {
        new CheckerGame();

    }

//---------------------------------------------------------------------------------------------------------------------------------------------   
    
    //method for printing a 8x8 checkerboard
    public void board() {
        Graphics g = getGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(100, 100, 400, 400);
        g.setColor(Color.BLACK);
        for (int i = 150; i <= 450; i += 100) {
            for (int j = 100; j <= 400; j += 100) {
                g.fillRect(i, j, 50, 50);
            }
        }

        for (int i = 100; i <= 400; i += 100) {
            for (int j = 150; j <= 450; j += 100) {
                g.fillRect(i, j, 50, 50);
            }
        }
        
    }

//---------------------------------------------------------------------------------------------------------------------------------------------       
    
    //method for detecting and displaying a gameover
    public void gameover() {
        Graphics g = getGraphics();
        if (bluelive == 0 || win == 1) {
            String msg = "Game Over BLUE WINS";
            Font small = new Font("Helvetica", Font.BOLD, 40);
            FontMetrics metr = getFontMetrics(small);
            g.setColor(Color.white);
            g.setFont(small);
            g.drawString(msg, (600 - metr.stringWidth(msg)) / 2, 80);
            selection = 2;
        } else if (redlive == 0 || win == 2) {
            String msg = "Game Over RED WINS";
            Font small = new Font("Helvetica", Font.BOLD, 40);
            FontMetrics metr = getFontMetrics(small);
            g.setColor(Color.white);
            g.setFont(small);
            g.drawString(msg, (600 - metr.stringWidth(msg)) / 2, 80);
            selection = 2;
        } 
        //draws the options to restart or quit
        if (selection == 2){
            Font small = new Font("Helvetica", Font.BOLD, 15);
            g.setFont(small);

            g.setColor(Color.GREEN);
            g.fillRect(100, 520, 100, 50);
            g.fillRect(400, 520, 100, 50);
            g.setColor(Color.BLACK);
            g.drawString("RESTART?", 110, 550);
            g.drawString("QUIT?", 425, 550);
            
            }
        }
    
//---------------------------------------------------------------------------------------------------------------------------------------------   
    
    //method for resetting the game: resets the checker positions and lives
    public void ResetPiece() {
        int count1 = 0;
        int count2 = 0;
        selection = 0;
        win=0;
        redlive = 12;
        bluelive = 12;
        turn = 1;
        for (int h = 0; h < 3; h++) {
            //Red Pieces starting x position
            for (int rx = 100; rx < 500; rx += 100) {

                if (h == 1) {
                    xred[count1] = rx;
                } else {
                    xred[count1] = rx + 50;
                }
                count1++;
            }
            //Red Pieces starting y position
            for (int b = 0; b < 4; b++) {
                yred[b] = 100;
                yred[b + 4] = 150;
                yred[b + 8] = 200;
            }
            //Blue Pieces starting x position
            for (int bx = 100; bx < 500; bx += 100) {
                if (h == 1) {
                    xblue[count2] = bx + 50;
                } else {
                    xblue[count2] = bx;
                }
                count2++;
            }
            //Blue Pieces starting y position
            for (int b = 0; b < 4; b++) {
                yblue[b] = 350;
                yblue[b + 4] = 400;
                yblue[b + 8] = 450;
            }
        }

    }

//---------------------------------------------------------------------------------------------------------------------------------------------   
    
    //method for drawing the checkerpieces on the screen
    public void print() {
        //Uses ellipse object to create all 24 red/blue pieces
        Graphics g = getGraphics();
        Ellipse2D red1 = new Ellipse2D.Double(xred[0], yred[0], 50, 50);
        Ellipse2D red2 = new Ellipse2D.Double(xred[1], yred[1], 50, 50);
        Ellipse2D red3 = new Ellipse2D.Double(xred[2], yred[2], 50, 50);
        Ellipse2D red4 = new Ellipse2D.Double(xred[3], yred[3], 50, 50);

        Ellipse2D red5 = new Ellipse2D.Double(xred[4], yred[4], 50, 50);
        Ellipse2D red6 = new Ellipse2D.Double(xred[5], yred[5], 50, 50);
        Ellipse2D red7 = new Ellipse2D.Double(xred[6], yred[6], 50, 50);
        Ellipse2D red8 = new Ellipse2D.Double(xred[7], yred[7], 50, 50);

        Ellipse2D red9 = new Ellipse2D.Double(xred[8], yred[8], 50, 50);
        Ellipse2D red10 = new Ellipse2D.Double(xred[9], yred[9], 50, 50);
        Ellipse2D red11 = new Ellipse2D.Double(xred[10], yred[10], 50, 50);
        Ellipse2D red12 = new Ellipse2D.Double(xred[11], yred[11], 50, 50);

        Ellipse2D blue1 = new Ellipse2D.Double(xblue[0], yblue[0], 50, 50);
        Ellipse2D blue2 = new Ellipse2D.Double(xblue[1], yblue[1], 50, 50);
        Ellipse2D blue3 = new Ellipse2D.Double(xblue[2], yblue[2], 50, 50);
        Ellipse2D blue4 = new Ellipse2D.Double(xblue[3], yblue[3], 50, 50);

        Ellipse2D blue5 = new Ellipse2D.Double(xblue[4], yblue[4], 50, 50);
        Ellipse2D blue6 = new Ellipse2D.Double(xblue[5], yblue[5], 50, 50);
        Ellipse2D blue7 = new Ellipse2D.Double(xblue[6], yblue[6], 50, 50);
        Ellipse2D blue8 = new Ellipse2D.Double(xblue[7], yblue[7], 50, 50);

        Ellipse2D blue9 = new Ellipse2D.Double(xblue[8], yblue[8], 50, 50);
        Ellipse2D blue10 = new Ellipse2D.Double(xblue[9], yblue[9], 50, 50);
        Ellipse2D blue11 = new Ellipse2D.Double(xblue[10], yblue[10], 50, 50);
        Ellipse2D blue12 = new Ellipse2D.Double(xblue[11], yblue[11], 50, 50);
        
        //paints all the pieces onto the board
        Graphics2D g2 = (Graphics2D) g;
        g2.setPaint(Color.RED);
        g2.fill(red1);
        g2.fill(red2);
        g2.fill(red3);
        g2.fill(red4);
        g2.fill(red5);
        g2.fill(red6);
        g2.fill(red7);
        g2.fill(red8);
        g2.fill(red9);
        g2.fill(red10);
        g2.fill(red11);
        g2.fill(red12);

        g2.setPaint(Color.BLUE);
        g2.fill(blue1);
        g2.fill(blue2);
        g2.fill(blue3);
        g2.fill(blue4);
        g2.fill(blue5);
        g2.fill(blue6);
        g2.fill(blue7);
        g2.fill(blue8);
        g2.fill(blue9);
        g2.fill(blue10);
        g2.fill(blue11);
        g2.fill(blue12);

    }

//---------------------------------------------------------------------------------------------------------------------------------------------   
    
    //method for locating a clicked piece
    public void findpiece(int x, int y) {
        
        //searches entire board, if the x and y position of mouse clicked matches then piece will be highlighted
        Graphics g = getGraphics();
        for (int i = 150; i <= 450; i += 100) {
            for (int j = 100; j <= 400; j += 100) {
                if (x >= i && x <= i + 50 && y >= j && y <= j + 50) {
                    switch (turn) {
                        //if blue turn, find blue piece
                        case 1:
                            findblue(i, j);
                            break;
                        //if red turn, find red piece
                        case 2:
                            findred(i, j);
                            break;
                        default:
                            break;
                    }

                }
            }
        }

        for (int i = 100; i <= 400; i += 100) {
            for (int j = 150; j <= 450; j += 100) {
                if (x >= i && x <= i + 50 && y >= j && y <= j + 50) {
                    switch (turn) {
                        //if blue turn, find blue piece
                        case 1:
                            findblue(i, j);
                            break;
                        //if red turn, find red piece
                        case 2:
                            findred(i, j);
                            break;
                        default:
                            break;
                    }
                }
            }
        }
    }

//---------------------------------------------------------------------------------------------------------------------------------------------   
    
    //method for finding and highlighting the blue piece
    public void findblue(int x, int y) {
        Graphics g = getGraphics();
        for (int i = 0; i <= xblue.length; i++) {
            if (xblue[i] == x && yblue[i] == y) {
                g.setColor(Color.YELLOW);
                g.drawOval(xblue[i] + 1, yblue[i] + 1, 48, 48);
                //searches for possible moves
                checkblue(xblue[i], yblue[i], i);

            }
        }
    }

//---------------------------------------------------------------------------------------------------------------------------------------------       
    
    //method for finding and highlighting the red piece
    public void findred(int x, int y) {
        Graphics g = getGraphics();
        for (int i = 0; i <= xred.length; i++) {
            if (xred[i] == x && yred[i] == y) {
                g.setColor(Color.YELLOW);
                g.drawOval(xred[i] + 1, yred[i] + 1, 48, 48);
                //searches for possible moves
                checkred(xred[i], yred[i], i);

            }
        }

    }

//---------------------------------------------------------------------------------------------------------------------------------------------       
    
    //Method to search and find potential moves for a blue piece
    public void checkblue(int x, int y, int num) {
        Graphics g = getGraphics();
        g.setColor(Color.YELLOW);
        count = 0;
        enemy1 = 0;
        enemy2 = 0;
        xval = 0;
        yval = 0;
        move = 0;
        pos1 = 0;
        pos2 = 0;
        pos3 = 0;
        pos4 = 0;
        pos5 = 0;
        pos6 = 0;
        selection = 1;
        for (int a = 0; a <= xblue.length; a++) {
            for (int k = a; k < xblue.length; k++) {
                //If team piece is to the left, square is full
                if ((xblue[a] == xblue[num] - 50) && (yblue[a] == yblue[num] - 50)) {
                    pos1 = 1;
                }
                //If team piece is to the right, square is full
                if ((xblue[a] == xblue[num] + 50) && (yblue[a] == yblue[num] - 50)) {
                    pos2 = 1;
                }

                //If enemy piece is to the left, square is full
                if ((xred[a] == xblue[num] - 50) && (yred[a] == yblue[num] - 50)) {
                    pos3 = 1;
                    enemy1 = a;
                }
                //If enemy piece is to the right, square is full
                if ((xred[a] == xblue[num] + 50) && (yred[a] == yblue[num] - 50)) {
                    pos4 = 1;
                    enemy2 = a;
                }

                //Pos5 and Pos6 only useful if there is a enemy piece beside
                //if team/enemy piece is diagonally left 2, square is full
                if ((xred[a] == xblue[num] - 100) && (yred[a] == yblue[num] - 100)) {
                    pos5 = 1;
                } else if ((xblue[a] == xblue[num] - 100) && (yblue[a] == yblue[num] - 100)) {
                    pos5 = 1;
                }
                //if team/enemy piece is diagonally right 2, square is full
                if ((xred[a] == xblue[num] + 100) && (yred[a] == yblue[num] - 100)) {
                    pos6 = 1;
                } else if ((xblue[a] == xblue[num] + 100) && (yblue[a] == yblue[num] - 100)) {
                    pos6 = 1;
                }

            }
        }
        //If conditions for seeing which squares are full and what the possible moves are 
        //Switch statements were not used to avoid a certain bug that occured only when switch was used
        //-------------------------------------------------------------------------------------------------------
        //if team piece are filling position 1 and 2, your piece cannot move
        if (pos1 == 1 && pos2 == 1) {
            move = 3;
        //if all 4 positions are filled while enemy pieces are beside, you cannot move
        } else if (pos3 == 1 && pos4 == 1 && pos5 == 1 && pos6 == 1) {
            move = 3;
        //if you have a team piece to the left, and cannot jump enemy to the right, you cannot move
        } else if (pos1 == 1 && pos4 == 1 && pos6 == 1) {
            move = 3;
        //if team piece is to the right, and cannot jump enemy to left, you cannot move
        } else if (pos2 == 1 && pos3 == 1 && pos5 == 1) {
            move = 3;
        //finds if you can only jump enemy piece to the right
        } else if (pos3 == 1 && pos4 == 1 && pos5 == 1) {
            move = 5;
        //finds if you can only jump enemy piece to the left
        } else if (pos3 == 1 && pos4 == 1 && pos6 == 1) {
            move = 4;
        //finds if you can only jump enemy piece to the right
        } else if (pos1 == 1 && pos4 == 1) {
            move = 5;
        //finds if you can only jump enemy piece to the left
        } else if (pos2 == 1 && pos3 == 1) {
            move = 4;
        //if you cannot jump enemy to left, you can only move to the right
        } else if (pos3 == 1 && pos5 == 1) {
            move = 2;
        //if you cannot jump enemy to right, you can only move left
        } else if (pos4 == 1 && pos6 == 1) {
            move = 1;
        //if you can jump enemy to left and right
        } else if (pos3 == 1 && pos4 == 1) {
            move = 6;
        //if team piece left, you can only move right          
        } else if (pos1 == 1) {
            move = 2;
        //if team piece right, you can only move left
        } else if (pos2 == 1) {
            move = 1;
        //if enemy piece left, you can only jump the enemy
        } else if (pos3 == 1) {
            move = 4;
        //if enemy piece right, you can only jump the enemy
        } else if (pos4 == 1) {
            move = 5;
        //if both left and right are free, you can move either direction
        } else{
            move=0;
        }
            
        //////////////////FINDS EXCEPTIONS///////////////////////////////

        //Checks if edge is to the left or right and then limits movement
        if ((xblue[num] - 50 < 100) && move == 1) {
            move = 3;
        } else if ((xblue[num] + 50 > 450) && move == 2) {
            move = 3;
        } else if ((xblue[num] - 100 < 100) && move == 4) {
            //if there is a open square piece can move there else there is no move
            if (pos2!=1 && pos4!=1){
                move = 2;
            } else{
              move = 3;
            }
        } else if ((xblue[num] + 100 > 450) && move == 5) {
            //if there is a open square piece can move there else there is no move
            if (pos1 != 1 && pos3 != 1){
                move = 1;
            } else{
              move = 3;
            }
        } else if ((xblue[num] - 50 < 100) && move == 0) {
            move = 2;
        } else if ((xblue[num] + 50 > 450) && move == 0) {
            move = 1;
        }
        
        //all of these will stop blue piece movement if the top of the board is too close
        if ((yblue[num] - 100 < 100) && move == 4) {
            move = 3;
        } else if ((yblue[num] - 100 < 100) && move == 5) {
            move = 3;
        } else if ((yblue[num] - 50 < 100) && move == 0) {
            move = 3;
        } else if ((yblue[num] - 50 < 100) && move == 1) {
            move = 3;
        } else if ((yblue[num] - 50 < 100) && move == 2) {
            move = 3;
        }
        
        //Will draw circles to highlight open positions
        if (move == 1) {
            g.fillOval(x - 35, y - 35, 20, 20);
        } else if (move == 2) {
            g.fillOval(x + 65, y - 35, 20, 20);
        } else if (move == 3) {
        } else if (move == 4) {
            g.fillOval(x - 85, y - 85, 20, 20);
        } else if (move == 5) {
            g.fillOval(x + 115, y - 85, 20, 20);
        }else if (move == 6) {
            g.fillOval(x - 85, y - 85, 20, 20);
            g.fillOval(x + 115, y - 85, 20, 20);
        } else {
            g.fillOval(x - 35, y - 35, 20, 20);
            g.fillOval(x + 65, y - 35, 20, 20);
        }
        
        //saves what piece is being highlighted and its x and y position
        count = num;
        xval = x;
        yval = y;
    }
    
//---------------------------------------------------------------------------------------------------------------------------------------------   
    
    //method for actually changing the position of the blue piece
    public void moveblue(int mousex, int mousey, int x, int y) {
        
        //All of these check for the possible movements and if the position of the mouse upon being clicked is on a valid square
        //you can move 1 square diagonally left or right
        if (move == 0) {
            if ((mousex >= x - 50 && mousex <= x && mousey >= y - 50 && mousey <= y)) {
                xblue[count] = x - 50;
                yblue[count] = y - 50;
                turn = 2;
            } else if ((mousex >= x + 50 && mousex <= x + 100 && mousey >= y - 50 && mousey <= y)) {
                xblue[count] = x + 50;
                yblue[count] = y - 50;
                turn = 2;
            }
        //you can move 1 square diagonally left
        } else if (move == 1) {
            if ((mousex >= x - 50 && mousex <= x && mousey >= y - 50 && mousey <= y)) {
                xblue[count] = x - 50;
                yblue[count] = y - 50;
                turn = 2;
            }
        //you can move 1 square diagonally right
        } else if (move == 2) {
            if ((mousex >= x + 50 && mousex <= x + 100 && mousey >= y - 50 && mousey <= y)) {
                xblue[count] = x + 50;
                yblue[count] = y - 50;
                turn = 2;
            }
        //piece cannot move
        } else if (move == 3) {
            //do nothing
            
        //can jump the enemy piece to the left
        } else if (move == 4) {
            if ((mousex >= x - 100 && mousex <= x - 50 && mousey >= y - 100 && mousey <= y - 50)) {
                xblue[count] = x - 100;
                yblue[count] = y - 100;
                xred[enemy1] = -100;
                yred[enemy1] = -100;
                redlive--;
                turn = 2;
            }
        //can jump the enemy piece to the right
        } else if (move == 5) {
            if ((mousex >= x + 100 && mousex <= x + 150 && mousey >= y - 100 && mousey <= y - 50)) {
                xblue[count] = x + 100;
                yblue[count] = y - 100;
                xred[enemy2] = -100;
                yred[enemy2] = -100;
                redlive--;
                turn = 2;
            }
        //can jump the enemy piece to the left or right
        } else if (move == 6) {
            if ((mousex >= x - 100 && mousex <= x - 50 && mousey >= y - 100 && mousey <= y - 50)) {
                xblue[count] = x - 100;
                yblue[count] = y - 100;
                xred[enemy1] = -100;
                yred[enemy1] = -100;
                redlive--;
                turn = 2;
            } else if ((mousex >= x + 100 && mousex <= x + 150 && mousey >= y - 100 && mousey <= y - 50)) {
                xblue[count] = x + 100;
                yblue[count] = y - 100;
                xred[enemy2] = -100;
                yred[enemy2] = -100;
                redlive--;
                turn = 2;
            }
        }
        
        //will go back to locating piece
        selection = 0;
        
        //if blue piece has reached the end of the board, blue wins
        if (yblue[count] == 100) {
            win = 1;
        }
    }

//---------------------------------------------------------------------------------------------------------------------------------------------   

    //Method to search and find potential moves for a red piece
    public void checkred(int x, int y, int num) {
        Graphics g = getGraphics();
        g.setColor(Color.YELLOW);
        enemy1 = 0;
        enemy2 = 0;
        count = 0;
        xval = 0;
        yval = 0;
        move = 0;
        pos1 = 0;
        pos2 = 0;
        pos3 = 0;
        pos4 = 0;
        pos5 = 0;
        pos6 = 0;
        selection = 1;
        for (int a = 0; a <= xred.length; a++) {
            for (int k = a; k < xred.length; k++) {
                //If team piece is to the left, square is full
                if ((xred[a] == xred[num] - 50) && (yred[a] == yred[num] + 50)) {
                    pos1 = 1;
                }
                //If team piece is to the right, square is full
                if ((xred[a] == xred[num] + 50) && (yred[a] == yred[num] + 50)) {
                    pos2 = 1;
                }
                //If enemy piece is to the left, square is full
                if ((xblue[a] == xred[num] - 50) && (yblue[a] == yred[num] + 50)) {
                    pos3 = 1;
                    enemy1 = a;
                }
                //If enemy piece is to the right, square is full                
                if ((xblue[a] == xred[num] + 50) && (yblue[a] == yred[num] + 50)) {
                    pos4 = 1;
                    enemy2 = a;
                }
                
                //Pos5 and Pos6 only useful if there is a enemy piece beside
                //if team/enemy piece is diagonally left 2, square is full              
                if ((xblue[a] == xred[num] - 100) && (yblue[a] == yred[num] + 100)) {
                    pos5 = 1;
                } else if ((xred[a] == xred[num] - 100) && (yred[a] == yred[num] + 100)) {
                    pos5 = 1;
                }
                
                //if team/enemy piece is diagonally right 2, square is full
                if ((xblue[a] == xred[num] + 100) && (yblue[a] == yred[num] + 100)) {
                    pos6 = 1;
                } else if ((xred[a] == xred[num] + 100) && (yred[a] == yred[num] + 100)) {
                    pos6 = 1;
                }

            }
        }
        //If conditions for seeing which squares are full and what the possible moves are 
        //Switch statements were not used to avoid a certain bug that occured only when switch was used
        //-------------------------------------------------------------------------------------------------------
        
        //if team piece are filling position 1 and 2, your piece cannot move
        if (pos1 == 1 && pos2 == 1) {
            move = 3;
            
        //if all 4 positions are filled while enemy pieces are beside, you cannot move
        } else if (pos3 == 1 && pos4 == 1 && pos5 == 1 && pos6 == 1) {
            move = 3;
            
        //if you have a team piece to the left, and cannot jump enemy to the right, you cannot move
        } else if (pos1 == 1 && pos4 == 1 && pos6 == 1) {
            move = 3;
            
        //if team piece is to the right, and cannot jump enemy to left, you cannot move
        } else if (pos2 == 1 && pos3 == 1 && pos5 == 1) {
            move = 3;
            
        //finds if you can only jump enemy piece to the right
        } else if (pos3 == 1 && pos4 == 1 && pos5 == 1) {
            move = 5;
            
        //finds if you can only jump enemy piece to the left
        } else if (pos3 == 1 && pos4 == 1 && pos6 == 1) {
            move = 4;
            
        //finds if you can only jump enemy piece to the right
        } else if (pos1 == 1 && pos4 == 1) {
            move = 5;
            
        //finds if you can only jump enemy piece to the left
        } else if (pos2 == 1 && pos3 == 1) {
            move = 4;
            
        //if you cannot jump enemy to left, you can only move to the right
        } else if (pos3 == 1 && pos5 == 1) {
            move = 2;
            
        //if you cannot jump enemy to right, you can only move left
        } else if (pos4 == 1 && pos6 == 1) {
            move = 1;
            
        //if you can jump enemy to left and right
        } else if (pos3 == 1 && pos4 == 1) {
            move = 6;
            
        //if team piece left, you can only move right   
        } else if (pos1 == 1) {
            move = 2;
            
        //if team piece right, you can only move left
        } else if (pos2 == 1) {
            move = 1;
            
        //if enemy piece left, you can only jump the enemy
        } else if (pos3 == 1) {
            move = 4;
            
        //if enemy piece right, you can only jump the enemy
        } else if (pos4 == 1) {
            move = 5;
            
        //if both left and right are free, you can move either direction
        } else{
            move=0;
        }
        
        
        //////////////////FINDS EXCEPTIONS///////////////////////////////
        
        //Checks if edge is to the left or right and then limits movement
        if ((xred[num] - 50 < 100) && move == 1) {
            move = 3;    
        } else if ((xred[num] + 50 > 450) && move == 2) {
            move = 3;     
        } else if ((xred[num] - 100 < 100) && move == 4) {
            move = 3;  
            //if there is a open square piece can move there else there is no move
            if (pos2!=1 && pos4!=1){
                move = 2;
            } else{
              move = 3;
            } 
            
        } else if ((xred[num] + 100 > 450) && move == 5) {
            move = 3;  
            //if there is a open square piece can move there else there is no move
            if (pos1 != 1 && pos3 != 1){
                move = 1;
            } else{
              move = 3;
            }
            
        } else if ((xred[num] - 50 < 100) && move == 0) {
            move = 2;     
        } else if ((xred[num] + 50 > 450) && move == 0) {
            move = 1;
        }
        
        //all of these will stop red piece movement if the bottom of the board is too close
        if ((yred[num] + 100 > 450) && move == 4) {
            move = 3;        
        } else if ((yred[num] + 100 > 450) && move == 5) {
            move = 3;     
        } else if ((yred[num] + 50 > 450) && move == 0) {
            move = 3;
        } else if ((yred[num] + 50 > 450) && move == 1) {
            move = 3;
        } else if ((yred[num] + 50 > 450) && move == 2) {
            move = 3;
        }

        //Will draw circles to highlight open positions
        if (move == 1) {
            g.fillOval(x - 35, y + 65, 20, 20);       
        } else if (move == 2) {
            g.fillOval(x + 65, y + 65, 20, 20);
        } else if (move == 3) {
        } else if (move == 4) {
            g.fillOval(x - 85, y + 115, 20, 20);
        } else if (move == 5) {
            g.fillOval(x + 115, y + 115, 20, 20);
        } else if (move == 6) {
            g.fillOval(x - 85, y + 115, 20, 20);
            g.fillOval(x + 115, y + 115, 20, 20);
        } else {
            g.fillOval(x - 35, y + 65, 20, 20);
            g.fillOval(x + 65, y + 65, 20, 20);
        }
        
        //saves what piece is being highlighted and its x and y position
        count = num;
        xval = x;
        yval = y;

    }
   
//---------------------------------------------------------------------------------------------------------------------------------------------    
    
    //method for actually changing the position of the red piece
    public void movered(int mousex, int mousey, int x, int y) {
        //All of these check for the possible movements and if the position of the mouse upon being clicked is on a valid square
        
        //you can move 1 square diagonally left or right
        if (move == 0) {
            if ((mousex >= x - 50 && mousex <= x && mousey >= y + 50 && mousey <= y + 100)) {
                xred[count] = x - 50;
                yred[count] = y + 50;
                turn = 1;
            } else if ((mousex >= x + 50 && mousex <= x + 100 && mousey >= y + 50 && mousey <= y + 100)) {
                xred[count] = x + 50;
                yred[count] = y + 50;
                turn = 1;
            }
            
        //you can move 1 square diagonally left
        } else if (move == 1) {
            if ((mousex >= x - 50 && mousex <= x && mousey >= y + 50 && mousey <= y + 100)) {
                xred[count] = x - 50;
                yred[count] = y + 50;
                turn = 1;
            }
            
        //you can move 1 square diagonally right
        } else if (move == 2) {
            if ((mousex >= x + 50 && mousex <= x + 100 && mousey >= y + 50 && mousey <= y + 100)) {
                xred[count] = x + 50;
                yred[count] = y + 50;
                turn = 1;
            }
            
        //piece cannot move     
        } else if (move == 3) {
            //do nothing
       
        //can jump the enemy piece to the left
        } else if (move == 4) {
            if ((mousex >= x - 100 && mousex <= x - 50 && mousey >= y + 100 && mousey <= y + 150)) {
                xred[count] = x - 100;
                yred[count] = y + 100;
                xblue[enemy1] = -100;
                yblue[enemy1] = -100;
                bluelive--;
                turn = 1;
            }
        
        //can jump the enemy piece to the right
        } else if (move == 5) {
            if ((mousex >= x + 100 && mousex <= x + 150 && mousey >= y + 100 && mousey <= y + 150)) {
                xred[count] = x + 100;
                yred[count] = y + 100;
                xblue[enemy2] = -100;
                yblue[enemy2] = -100;
                bluelive--;
                turn = 1;
            }
            
        //can jump the enemy piece to the left or right
        } else if (move == 6) {
            if ((mousex >= x - 100 && mousex <= x - 50 && mousey >= y + 100 && mousey <= y + 150)) {
                xred[count] = x - 100;
                yred[count] = y + 100;
                xblue[enemy1] = -100;
                yblue[enemy1] = -100;
                bluelive--;
                turn = 1;
            } else if ((mousex >= x + 100 && mousex <= x + 150 && mousey >= y + 100 && mousey <= y + 150)) {
                xred[count] = x + 100;
                yred[count] = y + 100;
                xblue[enemy2] = -100;
                yblue[enemy2] = -100;
                bluelive--;
                turn = 1;
            }
        }
        
        //will go back to locating piece
        selection = 0;
        //if red piece has reached the end of the board, red wins
        if (yred[count] == 450) {
            win = 2;
        }
    }
}
