package checkergame;

/**
 *
 * @author Arup
 */
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import java.awt.*;
import java.awt.Label;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;

/**
 *
 * @author S332686393
 */
public class Welcome {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        JFrame f = new JFrame("A JFrame");
        f.setSize(500, 500);
        f.setResizable(false);

        final JLabel label = new JLabel("Checkers by Arup, Andy, and Mo");
        label.setLocation(0, -170);
        label.setPreferredSize(new Dimension(10, 60));
        f.getContentPane().add(BorderLayout.NORTH, label);
        label.setSize(700, 500);
        label.setFont(new Font("Serif", Font.PLAIN, 35));

        final JLabel label2 = new JLabel("Welcome to 2 Player");
        label2.setLocation(30, 200);
        label2.setPreferredSize(new Dimension(10, 60));
        f.getContentPane().add(BorderLayout.NORTH, label2);
        label2.setSize(700, 500);
        label2.setFont(new Font("Serif", Font.PLAIN, 56));

        JLabel description = new JLabel("<html>Rules: Moving pieces work just like regular checkers however, there are no kings in the game."
                + " Instead, the first player to get their"
                + " piece to the end of the board wins. There is also no double jumping to make the matches more difficult.<br></html>");
        description.setBounds(10, 40, 70, 20);
        f.getContentPane().add(BorderLayout.CENTER, description);
        description.setFont(new Font("Serif", Font.PLAIN, 20));

        final JButton button = new JButton("Click Here to Play");
        f.getContentPane().add(BorderLayout.SOUTH, button);
        button.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent event) {
                CheckerGame MM = new CheckerGame();
                MM.setVisible(true);
                f.setVisible(false);

            }
        });

        f.setVisible(true);

    }
}
